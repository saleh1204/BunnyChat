BunnyChat is a web-based system that allows users to chat with each other.

It is built using PHP, JavaScript, HTML, and MySQL

Progress:
####----------------
(20%)
